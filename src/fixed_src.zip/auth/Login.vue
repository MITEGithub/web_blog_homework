<!-- eslint-disable vue/multi-word-component-names -->
<template>
  <div class="login-wrapper">
    <el-card class="login-card">
      <h2>登录</h2>
      <el-form label-position="top" :model="form">
        <el-form-item label="用户名">
          <el-input v-model="form.username" placeholder="请输入用户名" />
        </el-form-item>
        <el-form-item label="密码">
          <el-input v-model="form.password" type="password" placeholder="请输入密码" show-password />
        </el-form-item>
      </el-form>
      <el-button type="primary" class="w-full" @click="handleLogin">登录</el-button>
      <p class="form-hint">默认用户名：admin，密码：123456</p>
      <p class="form-link">
        没有账号？<router-link to="/register">去注册</router-link>
      </p>
    </el-card>
  </div>
</template>

<script setup>
import { reactive } from 'vue'
import { useRouter } from 'vue-router'
import axios from 'axios'

const router = useRouter()
const form = reactive({
  username: '',
  password: ''
})

const handleLogin = async () => {
  if (!form.username || !form.password) {
    alert('请填写完整信息')
    return
  }

  try {
    const res = await axios.post('/backend/api/login.php', form)
    if (res.data.token) {
      localStorage.setItem('token', res.data.token)
      alert('登录成功')
      router.push('/')
    } else {
      alert(res.data.error || '登录失败')
    }
  } catch (err) {
    alert('服务器异常')
  }
}
</script>

<style scoped>
.login-wrapper {
  display: flex;
  justify-content: center;
  align-items: center;
  height: 100vh;
}
.login-card {
  width: 400px;
}
.form-hint, .form-link {
  margin-top: 12px;
  color: #999;
  text-align: center;
}
</style>
