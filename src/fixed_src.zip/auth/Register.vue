<!-- eslint-disable vue/multi-word-component-names -->
<template>
  <div class="register-wrapper">
    <el-card class="register-card">
      <h2>注册</h2>
      <el-form label-position="top" :model="form">
        <el-form-item label="用户名">
          <el-input v-model="form.username" placeholder="请输入用户名" />
        </el-form-item>
        <el-form-item label="邮箱">
          <el-input v-model="form.email" placeholder="请输入邮箱" />
        </el-form-item>
        <el-form-item label="密码">
          <el-input v-model="form.password" type="password" show-password placeholder="请输入密码" />
        </el-form-item>
        <el-form-item label="确认密码">
          <el-input
            v-model="form.confirm"
            type="password"
            show-password
            placeholder="请再次输入密码"
          />
        </el-form-item>
      </el-form>
      <el-button type="primary" class="w-full" @click="handleRegister">注册</el-button>
      <p class="form-link">
        已有账号？<router-link to="/login">返回登录</router-link>
      </p>
    </el-card>
  </div>
</template>

<script setup>
import { reactive } from 'vue'
import { useRouter } from 'vue-router'
import axios from 'axios'

const router = useRouter()
const form = reactive({
  username: '',
  email: '',
  password: '',
  confirm: ''
})

const handleRegister = async () => {
  if (!form.username || !form.email || !form.password || !form.confirm) {
    alert('请填写完整信息')
    return
  }

  if (form.password !== form.confirm) {
    alert('两次密码不一致')
    return
  }

  try {
    const res = await axios.post('/backend/api/register.php', {
      username: form.username,
      email: form.email,
      password: form.password
    })

    if (res.data.token) {
      alert('注册成功，请登录')
      router.push('/login')
    } else {
      alert(res.data.error || '注册失败')
    }
  } catch (err) {
    alert('服务器异常')
  }
}
</script>

<style scoped>
.register-wrapper {
  display: flex;
  justify-content: center;
  align-items: center;
  height: 100vh;
}
.register-card {
  width: 400px;
}
.form-link {
  margin-top: 12px;
  text-align: center;
  color: #999;
}
</style>
