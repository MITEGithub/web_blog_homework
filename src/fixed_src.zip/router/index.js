import { createRouter, createWebHistory } from 'vue-router'
import Login from '@/auth/Login.vue'
import Register from '@/auth/Register.vue'

const routes = [
  { path: '/login', name: 'Login', component: Login },
  { path: '/register', name: 'Register', component: Register },
  { path: '/:pathMatch(.*)*', redirect: '/login' } // 所有未知路由重定向到登录
]

const router = createRouter({
  history: createWebHistory(),
  routes
})

export default router
