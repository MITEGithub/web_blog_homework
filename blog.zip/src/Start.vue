<!-- eslint-disable vue/multi-word-component-names -->
<template>
  <div class="home-page">
    <!-- 顶部导航栏 -->
    <div class="navbar">
      <div class="navbar-left">
        <img src="@/assets/logo.png" class="logo" />
        <span class="title">坤坤之家</span>
        <el-button type="text" link @click="$router.push('/')" class="nav-btn">
          <el-icon><HomeFilled /></el-icon> 首页
        </el-button>
        <el-button type="text" link @click="$router.push('/post')" class="nav-btn">
          <el-icon><Edit /></el-icon> 写文章
        </el-button>
        <el-button type="text" link @click="$router.push('/my-articles')" class="nav-btn">
          <el-icon><Notebook /></el-icon> 我的文章
        </el-button>
      </div>
      <div class="navbar-right">
        <el-button type="text" link @click="$router.push('/login')" class="nav-btn">
          <el-icon><User /></el-icon> 登录
        </el-button>
        <el-button type="text" link @click="$router.push('/register')" class="nav-btn">
          <el-icon><UserFilled /></el-icon> 注册
        </el-button>
      </div>
    </div>

    <!-- 主内容区域 -->
    <div class="main-wrapper">
      <!-- 左侧文章列表 -->
      <div class="center-panel">
        <h2 class="section-title">最新文章</h2>
        <div class="article-grid">
          <div v-for="article in articles" :key="article.id" class="article-card">
            <el-card class="article-elcard" shadow="hover">
              <h3 class="article-title">{{ article.title }}</h3>
              <p class="meta">
                <el-icon><User /></el-icon> {{ article.author }}&nbsp;&nbsp;
                <el-icon><Clock /></el-icon> {{ formatDate(article.created_at) }}&nbsp;&nbsp;
                <el-icon><View /></el-icon> {{ article.views }} 浏览
              </p>
              <p class="summary">{{ truncate(article.summary, 100) }}</p>
              <div class="card-actions">
                <el-button size="small" @click="likeArticle(article.id)">
                  <el-icon><Star /></el-icon> {{ article.likes }}
                </el-button>
                <el-button size="small">
                  <el-icon><ChatLineSquare /></el-icon> 评论
                </el-button>
                <el-button size="small" type="primary" link>阅读全文</el-button>
              </div>
            </el-card>
          </div>
        </div>
      </div>

      <!-- 右侧信息栏 -->
      <div class="right-panel">
        <!-- 网站统计 -->
        <div class="block-card">
          <div class="block-title">
            <el-icon><DataBoard /></el-icon> 网站统计
          </div>
          <div class="stat-group grid-layout">
            <div class="stat-item blue">
              <el-icon><Document /></el-icon>
              <div>
                <p class="stat-num">{{ stats.articles }}</p>
                <p class="stat-label">文章数</p>
              </div>
            </div>
            <div class="stat-item green">
              <el-icon><UserFilled /></el-icon>
              <div>
                <p class="stat-num">{{ stats.users }}</p>
                <p class="stat-label">用户数</p>
              </div>
            </div>
            <div class="stat-item orange">
              <el-icon><ChatLineSquare /></el-icon>
              <div>
                <p class="stat-num">{{ stats.comments }}</p>
                <p class="stat-label">评论数</p>
              </div>
            </div>
            <div class="stat-item red">
              <el-icon><Star /></el-icon>
              <div>
                <p class="stat-num">{{ stats.likes }}</p>
                <p class="stat-label">点赞数</p>
              </div>
            </div>
          </div>
        </div>

        <!-- 热门文章 -->
        <div class="block-card">
          <div class="block-title">
            <el-icon><Fire /></el-icon> 热门文章
          </div>
          <ul class="block-list">
            <li v-for="item in popular" :key="item.id">
              <el-icon><View /></el-icon> {{ item.title }}（{{ item.views }}）
            </li>
          </ul>
        </div>

        <!-- 最新评论 -->
        <div class="block-card">
          <div class="block-title">
            <el-icon><ChatDotRound /></el-icon> 最新评论
          </div>
          <ul class="block-list">
            <li v-for="c in comments" :key="c.id">
              <b>{{ c.user }}</b>：{{ c.content }}
            </li>
          </ul>
        </div>
      </div>
    </div>

    <!-- ✅ 分页组件固定底部 -->
    <div class="pagination-wrapper">
      <el-pagination
        background
        layout="prev, pager, next"
        :total="total"
        :page-size="20"
        :pager-count="7"
        @current-change="handlePageChange"
      />
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import axios from 'axios'
import {
  User, Clock, View, Star,
  ChatLineSquare, Document, UserFilled,
  Fire, ChatDotRound, DataBoard,
  HomeFilled, Edit, Notebook
} from '@element-plus/icons-vue'

const router = useRouter()
const articles = ref([])
const total = ref(0)
const stats = ref({ articles: 0, users: 0, comments: 0, likes: 0 })
const popular = ref([])
const comments = ref([])

const fetchArticles = async (page = 1) => {
  const res = await axios.get(`/backend/api/global/articles.php?page=${page}`)
  articles.value = res.data
  total.value = 1000
}
const fetchStats = async () => {
  const res = await axios.get('/backend/api/global/stats.php')
  stats.value = res.data
}
const fetchPopular = async () => {
  const res = await axios.get('/backend/api/global/popular.php')
  popular.value = res.data
}
const fetchComments = async () => {
  const res = await axios.get('/backend/api/global/comments.php')
  comments.value = res.data
}
const handlePageChange = (page) => {
  fetchArticles(page)
}
const likeArticle = async (id) => {
  await axios.post('/backend/api/articles/like.php', { article_id: id })
  fetchArticles()
}
const formatDate = (dateStr) => new Date(dateStr).toLocaleDateString()
const truncate = (str, len) => str.length > len ? str.slice(0, len) + '...' : str

onMounted(() => {
  if (localStorage.getItem('token') && router.currentRoute.value.path === '/start') {
    router.push('/home')
  } else {
    fetchArticles()
    fetchStats()
    fetchPopular()
    fetchComments()
  }
})
</script>

<style scoped>
@import 'animate.css';

.home-page {
  background: #f5f7fa;
  min-height: 100vh;
  padding-bottom: 70px;
}

/* 顶部导航栏（保留左右结构） */
.navbar {
  background: #0066ff;
  height: 52px;
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0 30px;
  color: white;
}
.navbar-left, .navbar-right {
  display: flex;
  align-items: center;
  gap: 14px;
}
.logo {
  height: 26px;
}
.title {
  font-size: 20px;
  font-weight: bold;
  color: white;
}
.nav-btn {
  font-size: 15px;
  color: white;
  padding: 4px 10px;
  border-radius: 6px;
}
.nav-btn:hover {
  background-color: rgba(255, 255, 255, 0.15);
  color: #cce6ff;
}

/* ✅ 主内容区域最大宽度 + 左右留白 */
.main-wrapper {
  max-width: 1300px;
  margin: 0 auto;
  padding: 0 24px;
  display: flex;
  gap: 24px;
}

.center-panel {
  flex: 1;
}
.right-panel {
  width: 260px;
  display: flex;
  flex-direction: column;
  gap: 20px;
}
.section-title {
  font-size: 24px;
  font-weight: bold;
  color: #007fff;
  border-bottom: 2px solid #007fff;
  display: inline-block;
  padding-bottom: 4px;
  margin-bottom: 16px;
}
.article-grid {
  display: flex;
  flex-wrap: wrap;
  gap: 20px;
}
.article-card {
  width: calc(50% - 10px);
}
.article-elcard {
  border-radius: 14px;
  padding: 16px;
}
.article-title {
  font-size: 18px;
  font-weight: bold;
  margin-bottom: 6px;
}
.meta {
  font-size: 13px;
  color: #999;
  margin-bottom: 8px;
}
.summary {
  font-size: 14px;
  color: #333;
  margin-bottom: 12px;
  line-height: 1.5;
}
.card-actions {
  display: flex;
  justify-content: space-between;
  gap: 8px;
}
.block-card {
  background: white;
  border-radius: 14px;
  padding: 16px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
}
.block-title {
  font-size: 16px;
  font-weight: bold;
  margin-bottom: 12px;
  display: flex;
  align-items: center;
  gap: 8px;
}
.block-list {
  list-style: none;
  padding-left: 0;
  font-size: 14px;
}
.block-list li {
  margin-bottom: 8px;
}
.grid-layout {
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  gap: 12px;
}
.stat-item {
  display: flex;
  align-items: center;
  gap: 10px;
  color: white;
  padding: 10px;
  border-radius: 12px;
}
.stat-num {
  font-size: 18px;
  font-weight: bold;
}
.stat-label {
  font-size: 12px;
  opacity: 0.9;
}
.blue { background: #409eff; }
.green { background: #67c23a; }
.orange { background: #e6a23c; }
.red { background: #f56c6c; }

/* ✅ 分页固定底部 + 居中 + 紧凑 */
.pagination-wrapper {
  position: fixed;
  bottom: 16px;
  left: 50%;
  transform: translateX(-50%);
  z-index: 10;
  background: #f5f7fa;
  padding: 8px 16px;
  border-radius: 8px;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);
}
</style>
