import { createRouter, createWebHistory } from 'vue-router'

import Start from '../Start.vue'
import Login from '../auth/Login.vue'
import Register from '../auth/Register.vue'

const routes = [
  {
    path: '/start',
    name: 'Start',
    component: Start
  },
  {
    path: '/login',
    name: 'Login',
    component: Login
  },
  {
    path: '/register',
    name: 'Register',
    component: Register
  },
  {
    path: '/',
    redirect: '/start' // 如果有人访问根路径，就重定向到 /start
  }
]

const router = createRouter({
  history: createWebHistory(),
  routes
})

export default router
