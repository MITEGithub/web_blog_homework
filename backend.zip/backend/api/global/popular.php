<?php
header('Content-Type: application/json; charset=utf-8');
require_once('../../config/db.php');

$sql = "SELECT a.id, a.title, a.views, a.likes, u.username AS author
        FROM articles a
        JOIN users u ON a.author_id = u.id
        ORDER BY a.views DESC
        LIMIT 5";

$result = $conn->query($sql);

$popular = [];
while ($row = $result->fetch_assoc()) {
    $popular[] = $row;
}

echo json_encode($popular, JSON_UNESCAPED_UNICODE);

