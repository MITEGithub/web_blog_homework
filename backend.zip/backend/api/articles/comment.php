<?php
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Headers: Content-Type');
header('Access-Control-Allow-Methods: POST');

require_once('../../config/db.php');

$data = json_decode(file_get_contents('php://input'), true);
$token = trim($data['token'] ?? '');
$article_id = intval($data['article_id'] ?? 0);
$content = trim($data['content'] ?? '');

if (!$token || !$article_id || !$content) {
    echo json_encode(['error' => '缺少参数'], JSON_UNESCAPED_UNICODE);
    exit;
}

// 获取用户 ID
$stmt = $conn->prepare("SELECT id FROM users WHERE token = ?");
$stmt->bind_param("s", $token);
$stmt->execute();
$res = $stmt->get_result();
$user = $res->fetch_assoc();

if (!$user) {
    echo json_encode(['error' => '无效的 token'], JSON_UNESCAPED_UNICODE);
    exit;
}

$user_id = $user['id'];

$stmt = $conn->prepare("INSERT INTO comments (user_id, article_id, content, created_at) VALUES (?, ?, ?, NOW())");
$stmt->bind_param("iis", $user_id, $article_id, $content);

echo json_encode($stmt->execute() ? ['message' => '评论成功'] : ['error' => '评论失败'], JSON_UNESCAPED_UNICODE);

