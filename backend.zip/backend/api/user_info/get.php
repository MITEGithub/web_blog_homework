<?php
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Headers: Content-Type');

require_once '../../config/db.php';

$headers = getallheaders();
$token = $headers['Authorization'] ?? '';

if (!$token) {
    echo json_encode(['error' => '未提供 token'], JSON_UNESCAPED_UNICODE);
    exit;
}

$sql = "SELECT id, username, email, role, created_at FROM users WHERE token = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $token);
$stmt->execute();
$result = $stmt->get_result();

if ($user = $result->fetch_assoc()) {
    echo json_encode(['user' => $user], JSON_UNESCAPED_UNICODE);
} else {
    echo json_encode(['error' => '无效 token'], JSON_UNESCAPED_UNICODE);
}

$stmt->close();
$conn->close();
?>

